import cv2

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read("trainer/student_trainer.yml")

labels = recognizer.getLabelsByString("")

print("Labels present in model:", labels)
