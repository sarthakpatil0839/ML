import cv2
import os
import numpy as np

face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

trainer_folder = "trainer"
if not os.path.exists(trainer_folder):
    os.makedirs(trainer_folder)

def train_recognizer(image_dir, output_file):
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    faces = []
    ids = []

    label_id = 0
    labels = {}

    for person_name in sorted(os.listdir(image_dir)):   # sorted → consistent IDs
        person_path = os.path.join(image_dir, person_name)
        if not os.path.isdir(person_path):
            continue

        print("Training:", person_name)

        for img_name in os.listdir(person_path):
            path = os.path.join(person_path, img_name)
            img = cv2.imread(path)

            if img is None:
                continue

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            detected_faces = face_cascade.detectMultiScale(gray, 1.3, 5)

            for (x, y, w, h) in detected_faces:
                face_roi = gray[y:y+h, x:x+w]
                faces.append(face_roi)
                ids.append(label_id)

        labels[label_id] = person_name
        label_id += 1

    if len(faces) == 0:
        print("❌ No faces found!")
        return

    recognizer.train(faces, np.array(ids))
    recognizer.write(output_file)

    print("\nTraining completed!")
    print("Saved:", output_file)
    print("Label Mapping:", labels)

# -------------------------
# Train Student Faces
# -------------------------
train_recognizer(
    "images/Students",
    "trainer/student_trainer.yml"
)

# -------------------------
# Train Staff Faces
# -------------------------
train_recognizer(
    "images/Staff",
    "trainer/staff_trainer.yml"
)
