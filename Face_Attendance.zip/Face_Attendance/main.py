import cv2
import pandas as pd
import os
from datetime import datetime


face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

student_recognizer = cv2.face.LBPHFaceRecognizer_create()
student_recognizer.read("trainer/student_trainer.yml")

staff_recognizer = cv2.face.LBPHFaceRecognizer_create()
staff_recognizer.read("trainer/staff_trainer.yml")

# -------------------------------
# STUDENT DETAILS (Add Yourself)
# -------------------------------
students = {
    0: {"name": "Arpita ", "roll": "41", "branch": "CO"},
    1: {"name": "Diptesh ", "roll": "33", "branch": "CSE"},   # ✔ YOU ADDED HERE
    2: {"name": "Shravani ", "roll": "20", "branch": "CO"},
    3: {"name": "Tanuraj ", "roll": "10", "branch": "CO"},


}

# -------------------------------
# STAFF DETAILS (Can add more)
# -------------------------------
staffs = {
    0: {"name": "Pruthviraj Dange", "branch": "Admin"},
    1: {"name": "Bob", "branch": "IT Support"},
}

student_file = "Students.xlsx"
staff_file = "Staff.xlsx"

for file, cols in [
    (student_file, ["Date", "Time", "Name", "Roll No", "Branch"]),
    (staff_file, ["Date", "Time", "Name", "Branch"])
]:
    if not os.path.exists(file):
        pd.DataFrame(columns=cols).to_excel(file, index=False)

marked_students = set()
marked_staffs = set()

def mark_student(id_):
    if id_ in marked_students:
        return "Already Marked"

    s = students.get(id_)
    now = datetime.now()

    df = pd.read_excel(student_file)
    df.loc[len(df)] = [
        now.strftime("%Y-%m-%d"),
        now.strftime("%H:%M:%S"),
        s["name"],
        s["roll"],
        s["branch"]
    ]
    df.to_excel(student_file, index=False)
    marked_students.add(id_)
    return "Attendance Marked"

def mark_staff(id_):
    if id_ in marked_staffs:
        return "Already Marked"

    s = staffs.get(id_)
    now = datetime.now()

    df = pd.read_excel(staff_file)
    df.loc[len(df)] = [
        now.strftime("%Y-%m-%d"),
        now.strftime("%H:%M:%S"),
        s["name"],
        s["branch"]
    ]
    df.to_excel(staff_file, index=False)
    marked_staffs.add(id_)
    return "Marked"

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:

        if w < 100 or h < 100:
            continue

        roi = gray[y:y+h, x:x+w]

        # ---------------- STUDENT ------------------
        student_id, conf_s = student_recognizer.predict(roi)

        if conf_s < 70:
            s = students.get(student_id)

            # Display full student info
            cv2.putText(frame, f"Name: {s['name']}", (x, y-50),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
            cv2.putText(frame, f"Roll: {s['roll']}", (x, y-25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
            cv2.putText(frame, f"Branch: {s['branch']}", (x, y-5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)

            msg = mark_student(student_id)
            cv2.putText(frame, msg, (x, y+h+30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255), 2)
            continue

        # ---------------- STAFF ------------------
        staff_id, conf_t = staff_recognizer.predict(roi)

        if conf_t < 70:
            s = staffs.get(staff_id)

            cv2.putText(frame, f"Name: {s['name']}", (x, y-35),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,0,0), 2)
            cv2.putText(frame, f"Branch: {s['branch']}", (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,0,0), 2)

            msg = mark_staff(staff_id)
            cv2.putText(frame, msg, (x, y+h+30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255), 2)
            continue

        # ---------------- UNKNOWN ------------------
        cv2.putText(frame, "Unknown", (x, y-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255), 2)

    cv2.imshow("Face Attendance System", frame)
    if cv2.waitKey(1) == 27:
        break

cap.release()
cv2.destroyAllWindows()
